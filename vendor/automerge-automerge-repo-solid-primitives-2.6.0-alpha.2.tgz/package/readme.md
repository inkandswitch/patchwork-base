# Solid Automerge

<a href="https://www.solidjs.com/">Solid</a> primitives for <a
href="https://automerge.org/docs/repositories/"> Automerge</a>.

```sh
pnpm add solid-js @automerge/automerge-repo @automerge/automerge-repo-solid-primitives
```

## useDocument ✨

Get a fine-grained live view of an automerge document from its URL.

When the handle receives changes, it converts the incoming automerge patch ops
to precise solid store updates, giving you fine-grained reactivity that's
consistent across space and time.

Returns `[doc, handle]`.

```ts
useDocument<T>(
    () => AutomergeURL,
    options?: {repo: Repo}
): [Doc<T>, DocHandle<T>]
```

```tsx
// example
const [url, setURL] = createSignal<AutomergeUrl>(props.url)
const [doc, handle] = useDocument(url, { repo })

const inc = () => handle()?.change(d => d.count++)
return <button onclick={inc}>{doc()?.count}</button>
```

The `{repo}` option can be left out if you are using [RepoContext](#repocontext).

## createDocumentProjection

Get a fine-grained live view from a signal automerge `DocHandle`.

Underlying primitive for [`useDocument`](#usedocument-).

Works with [`useHandle`](#usehandle).

```ts
createDocumentProjection<T>(() => AutomergeUrl): Doc<T>
```

```tsx
// example
const handle = repo.find(url)
const doc = makeDocumentProjection<{ items: { title: string }[] }>(handle)

// subscribes fine-grained to doc.items[1].title
return <h1>{doc.items[1].title}</h1>
```

## makeDocumentProjection

Just like `createDocumentProjection`, but without a reactive input.

Underlying primitive for [`createDocumentProjection`](#createDocumentProjection).

```ts
makeDocumentProjection<T>(handle: Handle<T>): Doc<T>
```

```tsx
// example
const handle = repo.find(url)
const doc = makeDocumentProjection<{ items: { title: string }[] }>(handle)

// subscribes fine-grained to doc.items[1].title
return <h1>{doc.items[1].title}</h1>
```

## useDocSignal

A light coarse-grained primitive when you care only _that_ a doc has changed,
and not _how_. Returns `[doc, handle]`.

```ts
useDocSignal<T>(
    () => AutomergeURL,
    options?: {repo: Repo}
): [Accessor<Doc<T>>, Resource<DocHandle<T>>]
```

```tsx
// example
const [url, setURL] = createSignal<AutomergeUrl>(props.url)
const [doc, handle] = useDocSignal(url, { repo })

const inc = () => handle()?.change(d => d.count++)
return <button onclick={inc}>{doc()?.count}</button>
```

The `{repo}` option can be left out if you are using [RepoContext](#repocontext).

## createDocSignal

A light coarse-grained primitive when you care only _that_ a doc has changed,
and not _how_. Takes a signal `DocHandle`.

Underlying primitive for [`useDocSignal`](#usedocsignal).

Works with [`useDocHandle`](#usedochandle).

```ts
createDocSignal<T>(() => DocHandle<T>): Accessor<Doc<T>>
```

## makeDocSignal

Just like `createDocSignal`, but without a reactive input.

Underlying primitive for [`createDocSignal`](#createdocsignal).

```ts
makeDocSignal<T>(handle: DocHandle<T>): Accessor<Doc<T>>
```

```tsx
// example
const handle = repo.find(url)
const doc = makeDocSignal<{ count: number }>(handle)

return <span>{doc()?.count}</span>
```

## useDocHandle

Get a [DocHandle](https://automerge.org/docs/repositories/dochandles/) from the
repo as a
[resource](https://docs.solidjs.com/reference/basic-reactivity/create-resource).

Perfect for handing to `createDocumentProjection`.

```ts
useDocHandle<T>(
    () => AnyDocumentId,
    options?: {repo: Repo}
): Resource<Handle<T>>
```

```tsx
const handle = useDocHandle(id, { repo })
// or
const handle = useDocHandle(id)
```

The `repo` option can be left out if you are using [RepoContext](#repocontext).

## context

If you prefer the context pattern for some reason, you can pass the repo higher
up in your app with `RepoContext`

### `RepoContext`

A convenience context for Automerge-Repo Solid apps. Optional: if you prefer you
can pass a repo as an option to `useDocHandle` and `useDocument`.

```tsx
<RepoContext.Provider repo={Repo}>
  <App />
</RepoContext.Provider>
```

### `useRepo`

Get the repo from the [context](#repocontext).

```ts
useRepo(): Repo
```

#### e.g.

```ts
const repo = useRepo()
```
