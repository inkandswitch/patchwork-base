import { onCleanup } from "solid-js"
import type {
  Doc,
  DocHandle,
  DocHandleChangePayload,
  UrlHeads,
} from "@automerge/automerge-repo/slim"
import autoproduce from "./autoproduce.js"
import { createStore, produce, reconcile, type Store } from "solid-js/store"
import { applyPatches, getHeads } from "@automerge/automerge/slim"

const cache = new WeakMap<
  DocHandle<unknown>,
  {
    refs: number
    store: Store<Doc<unknown>>
    cleanup(): void
  }
>()

/**
 * Identity of a whole-document position. The store is a replica maintained
 * by replaying patch batches, and a batch is only valid against the exact
 * document state it was produced from, so each batch's `patchInfo.before`
 * is checked against the position the store currently represents.
 */
function headsKey(doc: Doc<unknown>): string {
  return getHeads(doc).slice().sort().join("\n")
}

function initial<T>(handle: DocHandle<T>): T {
  const template = {} as T
  if (!handle.isDeleted()) {
    applyPatches(
      template,
      handle.diff([] as unknown as UrlHeads, handle.heads())
    )
  }
  return template
}

/**
 * make a fine-grained live view of a document from its handle.
 * @param handle an Automerge
 * [DocHandle](https://automerge.org/automerge-repo/classes/_automerge_automerge_repo.DocHandle.html)
 */
export default function makeDocumentProjection<T extends object>(
  handle: DocHandle<T>
): Doc<T> {
  onCleanup(() => {
    const item = cache.get(handle)!
    if (!item) return
    if (!item.refs--) {
      item.cleanup()
    }
  })

  if (cache.has(handle)) {
    const item = cache.get(handle)!
    item.refs++
    return item.store as T
  }

  const [doc, set] = createStore<T>(initial(handle))
  // The whole-document heads the store is at right now. `fullDoc()` (not
  // `doc()`) because change payloads carry whole-document `patchInfo`
  // snapshots even on scoped sub-handles.
  let storeHeads = handle.isDeleted() ? undefined : headsKey(handle.fullDoc())

  cache.set(handle, {
    refs: 0,
    store: doc,
    cleanup() {
      handle.off("change", patch)
      handle.off("delete", ondelete)
      // https://github.com/chee/solid-automerge/pull/5
      cache.delete(handle)
    },
  })

  function patch(payload: DocHandleChangePayload<T>) {
    // Patches can only be replayed when the store is exactly at the batch's
    // "before" position. A mismatch means this batch must not be applied
    // patch-by-patch — e.g. the projection was created mid-dispatch (store
    // writes propagate synchronously through Solid, re-entering user code
    // that makes new projections) and seeded from the post-change document,
    // so replaying the in-flight batch would double-apply it. Reconcile from
    // the canonical post-change doc instead; that is correct from any state.
    // `scopeReplaced` flags a wholesale change at/above a sub-document
    // handle, where patches don't describe the new scope either.
    if (
      payload.scopeReplaced ||
      headsKey(payload.patchInfo.before) !== storeHeads
    ) {
      set(reconcile((payload.doc ?? {}) as T))
    } else {
      set(produce(autoproduce(payload)))
    }
    storeHeads = headsKey(payload.patchInfo.after)
  }

  function ondelete() {
    set(reconcile({} as T))
    storeHeads = undefined
  }

  handle.on("change", patch)
  handle.on("delete", ondelete)

  return doc
}
